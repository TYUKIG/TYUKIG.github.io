let mapped; // varible to hold mapped x position
let imageY = 200;
function preload(){ 
  img = loadImage('download.jpg'); //load image after uploading to file system
}

function setup() {
  createCanvas(400, 400);
  noCursor(); //stops cursor from being shown over canvas
  
}

function draw() {
  background(90);
  textSize(20);
  textAlign(CENTER);
  textFont("Courier")
  text("i can believe I can fly",200,90)
 mappedX = map (mouseX, 0, width, 0, width - 200, 90)
  image(img,mouseX-200,mouseY-100,290,99);
  
  //the width attribute of the image is based on the file, not the pixels drawn to the canvas
  console.log(img.width);
}